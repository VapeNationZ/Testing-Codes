This is for BLOGs
